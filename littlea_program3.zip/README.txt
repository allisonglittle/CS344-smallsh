Compile code with the following command:
gcc -std=gnu99 -g -Wall -o smallsh smallsh.c

AS OF 2/7/22: I plan to submit a revised version. Please do not grade this one.
I will submit a revision that meets all requirements in the next 3 days.
AS OF 2/8/22: This is still not my final version. I plan to submit a revised version. Please do not grade this one.
I will submit a revision that meets all requirements in the next 3 days.